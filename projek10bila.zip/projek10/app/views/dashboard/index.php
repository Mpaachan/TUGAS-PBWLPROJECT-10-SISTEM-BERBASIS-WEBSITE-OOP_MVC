<h2>JILBABKU JILBAB KITA</h2>

<div class="info">Butuh jilbab model apa kak? <b>disini aja</b></div>
<div class="info">Kak, buk. Kalau cari jilbab sama kita aja ya! Pilih sesuai model dan warna!
            
</div>
<div class="info"><b>BUTUH JILBAB? DI JILBABKU JILBAB KITA AZZA!</b></div>
<div class="info"><b>Jilbab</b>
    <p>- Ceruti</p>
    <p>- Katun</p>
    <p>- Kaos</p>
    <p>- Wolfis</p>
    <p>- Crinkle</p>
</div>