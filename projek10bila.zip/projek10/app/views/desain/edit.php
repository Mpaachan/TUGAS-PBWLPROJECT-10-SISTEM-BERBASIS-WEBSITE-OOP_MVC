<h2>Edit Book</h2>

<form action="<?php echo URL; ?>/book/update" method="post">
    <input type="hidden" name="id" value="<?php echo $data['row']['book_id']; ?>">
    <table>
        <tr>
            <td>NAME</td>
            <td><input type="text" name="book_nama" value="<?php echo $data['row']['book_nama']; ?>" required></td>
        </tr>
        <tr>
            <td>HARGA</td>
            <td><input type="text" name="book_harga" value="<?php echo $data['row']['book_harga']; ?>" required></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>