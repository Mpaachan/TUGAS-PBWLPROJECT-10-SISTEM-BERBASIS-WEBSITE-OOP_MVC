<h2>Input Jilbabku Jilbab Kita</h2>

<form action="<?php echo URL; ?>/jilbab/save" method="post">
    <table>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="jilbab_nama" required></td>
        </tr>
        <tr>
            <td>HARGA</td>
            <td><input type="text" name="jilbab_harga" required></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_save" value="SAVE"></td>
        </tr>
    </table>
</form>