<h2>JILBABKU JILBAB KITA</h2>

<a href="<?php echo URL; ?>/jilbab/input" class="btn">Input Jilbabku Jilbab Kita</a>

<table id="dtb">
<thead>
      <tr>
            <th>NO</th>
            <th>ID JILBAB</th>
            <th>NAMA JILBAB</th>
            <th>HARGA</th>
            <th>EDIT</th>
      </tr> 
    </thead>
    <tbody>
      <?php $no = 1;
      foreach ($data['rows'] as $row) { ?>
            <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $row['jilbab_id']; ?></td>
                  <td><?php echo $row['jilbab_nama']; ?></td>
                  <td><?php echo $row['jilbab_harga']; ?></td>
                  <td><a href="<?php echo URL; ?>/jilbab/edit/<?php echo $row['jilbab_id']; ?>" class="btn">Edit</a></td>
            </tr>
      <?php $no++;
      } ?>
      </tbody>

</table>