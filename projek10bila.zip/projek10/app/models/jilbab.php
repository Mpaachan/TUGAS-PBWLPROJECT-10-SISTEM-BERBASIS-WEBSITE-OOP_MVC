<?php

namespace App\Models;

use App\Core\Model;

class jilbab extends Model
{

     public function show()
     {
          $query = "SELECT * FROM tb_jilbab";
          $stmt = $this->db->prepare($query);
          $stmt->execute();

          return $this->selects($stmt);
     }

     public function save()
     {
          $jilbab_nama = $_POST['jilbab_nama'];
          $jilbab_harga = $_POST['jilbab_harga'];

          $sql = "INSERT INTO tb_jilbab SET jilbab_nama=:jilbab_nama, jilbab_harga=:jilbab_harga";
          $stmt = $this->db->prepare($sql);

          $stmt->bindParam(":jilbab_nama", $jilbab_nama);
          $stmt->bindParam(":jilbab_harga", $jilbab_harga);

          $stmt->execute();
     }

     public function edit($id)
     {
          $query = "SELECT * FROM tb_jilbab WHERE jilbab_id=:jilbab_id";
          $stmt = $this->db->prepare($query);

          $stmt->bindParam(":jilbab_id", $id);
          $stmt->execute();

          return $this->select($stmt);
     }

     public function update()
     {
          $jilbab_nama = $_POST['jilbab_nama'];
          $jilbab_harga = $_POST['jilbab_harga'];
          $id = $_POST['id'];

          $sql = "UPDATE tb_jilbab
          SET jilbab_nama=:jilbab_nama, jilbab_harga=:jilbab_harga WHERE jilbab_id=:jilbab_id";

          $stmt = $this->db->prepare($sql);

          $stmt->bindParam(":jilbab_nama", $jilbab_nama);
          $stmt->bindParam(":jilbab_harga", $jilbab_harga);
          $stmt->bindParam(":jilbab_id", $id);

          $stmt->execute();
     }
}
